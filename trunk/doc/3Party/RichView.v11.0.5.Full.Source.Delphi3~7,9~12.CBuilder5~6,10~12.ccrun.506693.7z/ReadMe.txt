RichView 11.0.5
Full source code (without help and demo projects)

See "New in version 11" in the help file.

Additional files:

Help file (CHM):
http://www.trichview.com/rvfiles/rvchm.zip
Help file (HLP):
http://www.trichview.com/rvfiles/rvchm.zip
PDF manual:
http://www.trichview.com/rvfiles/rv_pdf_manual.zip
RTF manual: 
http://www.trichview.com/rvfiles/rv_rtf_manual.zip

Delphi 4-2007 demos: 
http://www.trichview.com/rvfiles/delphidemos.zip
Delphi 2009 demos: 
http://www.trichview.com/rvfiles/delphiunidemos.zip
C++Builder 4-2007 demos:
http://www.trichview.com/rvfiles/cbdemos.zip
C++Builder 2009 demos:
http://www.trichview.com/rvfiles/cbunidemos.zip

RichViewActions:
http://www.trichview.com/resources/actions/richviewactions.zip

==========================================================

v11.0.5 (2009-Apr-14)
fixes and tweaks

v11.0.4 (2009-Mar-03)
fixes and tweaks

v11.0.3 (2009-Jan-22)
fixes and tweaks

v11.0.2 (2008-Dec-13)
fix: related to "exactly" line spacing

v11.0.1 (2008-Dec-4)
fix: changes for ScaleRichView.

v11.0.0 (2008-Dec-1)
